# TrainTrack Pro — v1.0.0

Initial Android release.

## Included
- Native Android app using Kotlin + Jetpack Compose + Material 3
- Local persistence with Room
- Training-plan management
- Statistics with period navigation and drill-down
- PWA preview under `pwa/`

## Build
The repository includes a GitHub Actions workflow. Push a version tag such as `v1.0.0` to build the release APK and create a GitHub Release automatically.

> The uploaded project does not contain a Gradle wrapper JAR, so the CI workflow installs Gradle 9.6 explicitly.
