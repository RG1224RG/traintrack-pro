# TrainTrack Pro

Native Android starter/application shell using Kotlin + Jetpack Compose + Material 3 + Room + Coroutines + MVVM, with a small PWA preview.

## Stack
- Package: `com.traintrack.pro`
- Local-only single profile (`userId = 1`)
- Room 2.8.5
- Compose BOM 2026.09.00
- AGP 9.4.0 / Gradle 9.6.0
- Vico 3.2.1
- Lottie Compose 6.7.1

## Core behavior
- `baseReps` is immutable after exercise creation.
- A chip tap writes only today’s delta to `DailyLog`. Absolute input is converted to `absolute - baseReps`.
- Tomorrow naturally falls back to the exercise base because logs are keyed by `date + exerciseId`.
- Daily total is `SUM(delta)`; completion rate is completed exercises divided by total exercises.
- Weekly/monthly/yearly aggregations are generated from DailyLog. Year view uses 52 weekly bars.

## Open
Open the root folder in Android Studio Quail 4 (or newer) and sync. The wrapper properties target Gradle 9.6.0.

## Preview
Open `pwa/index.html` in a static server for the browser preview. The PWA is intentionally a preview only; persistence/source of truth lives in the native Room layer.

## Implemented UI interactions
- Long press: edit exercise dialog.
- Swipe left: delete exercise.
- Long-press drag: move exercise by one position; LazyColumn item placement animates.
- Checkbox: local completion state + haptic feedback + Lottie check animation.
- Orange target chip: `+7`, `-7`, or absolute number (e.g. `22`).
- Statistics: Vico vertical rounded bars, horizontal chart scroll, left/right period navigation and horizontal swipe navigation.
- Year → week drill-down; week/month/today → daily bottom-sheet drill-down with stored breakdown and total sum.

## Build note
The source tree was generated and statically sanity-checked in this environment. Android/Gradle dependency resolution is intentionally left to Android Studio/Gradle because the sandbox has no configured Android SDK installation.

## GitHub Release

This repository is configured to publish an Android APK automatically when a version tag is pushed:

```bash
git add .
git commit -m "Prepare TrainTrack Pro 1.0.0"
git tag v1.0.0
git push origin main
git push origin v1.0.0
```

GitHub Actions will build `app-release.apk` and attach it to the corresponding GitHub Release.
