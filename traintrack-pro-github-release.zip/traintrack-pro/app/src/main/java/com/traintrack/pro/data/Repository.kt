package com.traintrack.pro.data

import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.first
import java.time.DayOfWeek
import java.time.LocalDate
import java.time.YearMonth
import java.time.temporal.WeekFields
import java.time.temporal.TemporalAdjusters
import java.util.Locale

class TrainTrackRepository(
    private val exerciseDao: ExerciseDao,
    private val dailyLogDao: DailyLogDao,
    private val dailyTotalDao: DailyTotalDao,
) {
    fun observeExercises(): Flow<List<Exercise>> = exerciseDao.observeExercises()

    fun observeToday(date: LocalDate): Flow<List<DailyLogWithExercise>> = dailyLogDao.observeLogs(date.toString())

    suspend fun addExercise(name: String, baseReps: Int, baseSets: Int) {
        exerciseDao.insert(Exercise(name = name, baseReps = baseReps, baseSets = baseSets, sortOrder = System.currentTimeMillis().toInt()))
    }

    suspend fun updateExercise(exercise: Exercise, name: String, baseSets: Int) {
        // baseReps deliberately stays immutable after creation.
        exerciseDao.update(exercise.copy(name = name, baseSets = baseSets))
    }

    suspend fun deleteExercise(exercise: Exercise) {
        dailyLogDao.deleteForExercise(exercise.id)
        exerciseDao.delete(exercise)
        refreshDailyTotal(LocalDate.now())
    }

    suspend fun reorder(exercises: List<Exercise>) {
        exercises.forEachIndexed { index, exercise -> exerciseDao.updateSortOrder(exercise.id, index) }
    }

    suspend fun setCompleted(date: LocalDate, exerciseId: Long, completed: Boolean) {
        val existing = dailyLogDao.find(date.toString(), exerciseId)
        val base = existing?.baseReps ?: 0
        if (existing == null) {
            // base must be supplied by ViewModel via ensure log; this branch is replaced by ensureLog below.
        } else {
            dailyLogDao.setCompleted(date.toString(), exerciseId, completed)
        }
    }

    suspend fun setCompleted(date: LocalDate, exercise: Exercise, completed: Boolean) {
        val key = date.toString()
        val existing = dailyLogDao.find(key, exercise.id)
        dailyLogDao.upsert(
            (existing ?: DailyLog(date = key, exerciseId = exercise.id, baseReps = exercise.baseReps)).copy(isCompleted = completed, actualReps = exercise.baseReps + (existing?.delta ?: 0))
        )
        refreshDailyTotal(date)
    }

    suspend fun saveDelta(date: LocalDate, exercise: Exercise, rawInput: String) {
        val trimmed = rawInput.trim()
        if (trimmed.isEmpty()) return
        val delta = when {
            trimmed.startsWith("+") || trimmed.startsWith("-") -> trimmed.toIntOrNull() ?: return
            else -> {
                val absolute = trimmed.toIntOrNull() ?: return
                absolute - exercise.baseReps
            }
        }
        val key = date.toString()
        val existing = dailyLogDao.find(key, exercise.id)
        dailyLogDao.upsert(
            DailyLog(
                id = existing?.id ?: 0,
                date = key,
                exerciseId = exercise.id,
                baseReps = exercise.baseReps,
                delta = delta,
                actualReps = exercise.baseReps + delta,
                isCompleted = existing?.isCompleted ?: false,
            )
        )
        refreshDailyTotal(date)
    }

    suspend fun refreshDailyTotal(date: LocalDate) {
        val key = date.toString()
        val total = dailyLogDao.sumDelta(key)
        val exercises = dailyLogDao.countExercises()
        val completed = dailyLogDao.countCompleted(key)
        val rate = if (exercises == 0) 0f else completed * 100f / exercises
        dailyTotalDao.upsert(DailyTotal(key, total, rate))
    }

    suspend fun exerciseCount(): Int = dailyLogDao.countExercises()
    suspend fun allExercises(): List<Exercise> = exerciseDao.observeExercises().first()
    suspend fun logsBetween(from: LocalDate, to: LocalDate): List<DailyLog> = dailyLogDao.getBetween(from.toString(), to.toString())
    suspend fun logsForDate(date: LocalDate): List<DailyLogWithExercise> =
        dailyLogDao.observeLogs(date).first()

    fun periodDates(filter: StatsFilter, anchor: LocalDate): Pair<LocalDate, LocalDate> = when (filter) {
        StatsFilter.TODAY -> anchor to anchor
        StatsFilter.WEEK -> {
            val start = anchor.with(TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY))
            start to start.plusDays(6)
        }
        StatsFilter.MONTH -> {
            val start = YearMonth.from(anchor).atDay(1)
            start to YearMonth.from(anchor).atEndOfMonth()
        }
        StatsFilter.SIX_MONTHS -> {
            val start = YearMonth.from(anchor).minusMonths(5).atDay(1)
            start to YearMonth.from(anchor).atEndOfMonth()
        }
        StatsFilter.YEAR -> {
            val start = anchor.with(TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY))
            start to start.plusWeeks(52).minusDays(1)
        }
    }

    suspend fun aggregatedWeek(anchor: LocalDate): List<StatsBar> {
        val start = anchor.with(TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY))
        return (0..6).map { offset -> aggregateDay(start.plusDays(offset.toLong())) }
    }

    suspend fun aggregatedMonth(anchor: LocalDate): List<StatsBar> {
        val start = YearMonth.from(anchor).atDay(1)
        val end = YearMonth.from(anchor).atEndOfMonth()
        return generateSequence(start) { it.plusDays(1) }.takeWhile { !it.isAfter(end) }.map { aggregateDay(it) }.toList()
    }

    suspend fun aggregatedSixMonths(anchor: LocalDate): List<StatsBar> {
        val end = YearMonth.from(anchor).atEndOfMonth()
        val start = YearMonth.from(anchor).minusMonths(5).atDay(1)
        return generateSequence(start) { it.plusDays(7) }.takeWhile { !it.isAfter(end) }.map { weekStart ->
            aggregateRange(weekStart, minOf(weekStart.plusDays(6), end))
        }.toList()
    }

    suspend fun aggregatedYear(anchor: LocalDate): List<StatsBar> =
        (0 until 52).map { index ->
            val start = anchor.withDayOfYear(1).with(TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY)).plusWeeks(index.toLong())
            aggregateRange(start, start.plusDays(6))
        }

    suspend fun detailedDay(anchor: LocalDate): List<StatsBar> = {
        val logs = logsForDate(anchor)
        logs.map { StatsBar(it.exerciseName, anchor, it.delta, if (it.isCompleted) 100f else 0f, it.isCompleted) }
    }

    private suspend fun aggregateDay(date: LocalDate): StatsBar {
        val logs = dailyLogDao.getForDate(date.toString())
        val total = logs.sumOf { it.delta }
        val completed = logs.count { it.isCompleted }
        val exercises = dailyLogDao.countExercises()
        val rate = if (exercises == 0) 0f else completed * 100f / exercises
        return StatsBar(dateLabel(date), date, total, rate, completed == exercises && exercises > 0)
    }

    private suspend fun aggregateRange(start: LocalDate, end: LocalDate): StatsBar {
        val logs = logsBetween(start, end)
        val total = logs.sumOf { it.delta }
        val days = (0..(java.time.temporal.ChronoUnit.DAYS.between(start, end).toInt())).map { start.plusDays(it.toLong()) }
        val exerciseCount = dailyLogDao.countExercises()
        val completedSlots = logs.count { it.isCompleted }
        val rate = if (days.isEmpty() || exerciseCount == 0) 0f else completedSlots * 100f / (days.size * exerciseCount)
        return StatsBar("KW ${start.get(WeekFields.ISO.weekOfWeekBasedYear())}", start, total, rate, rate >= 99.9f)
    }

    private fun dateLabel(date: LocalDate): String = date.dayOfMonth.toString().padStart(2, '0') + "." + date.monthValue.toString().padStart(2, '0')

    private fun minOf(a: LocalDate, b: LocalDate) = if (a <= b) a else b
}

enum class StatsFilter(val label: String) { TODAY("Täglich"), WEEK("Woche"), MONTH("Monat"), SIX_MONTHS("6 Monate"), YEAR("Jahre") }

data class StatsBar(
    val label: String,
    val date: LocalDate,
    val value: Int,
    val completionRate: Float,
    val complete: Boolean,
)
