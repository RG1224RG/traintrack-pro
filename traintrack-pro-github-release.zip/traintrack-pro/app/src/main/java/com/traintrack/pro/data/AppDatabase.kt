package com.traintrack.pro.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(entities = [Exercise::class, DailyLog::class, DailyTotal::class], version = 1, exportSchema = true)
abstract class AppDatabase : RoomDatabase() {
    abstract fun exerciseDao(): ExerciseDao
    abstract fun dailyLogDao(): DailyLogDao
    abstract fun dailyTotalDao(): DailyTotalDao
}

object DatabaseProvider {
    @Volatile private var INSTANCE: AppDatabase? = null

    fun get(context: Context): AppDatabase = INSTANCE ?: synchronized(this) {
        INSTANCE ?: Room.databaseBuilder(
            context.applicationContext,
            AppDatabase::class.java,
            "traintrack_pro.db",
        ).build().also { INSTANCE = it }
    }
}
