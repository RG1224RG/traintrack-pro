package com.traintrack.pro.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color

val PrimaryBlue = Color(0xFF0D47A1)
val AccentOrange = Color(0xFFFF6D00)
val BgDark = Color(0xFF121A26)
val BgLight = Color(0xFFF8FAFF)
val PositiveGreen = Color(0xFF4CAF50)
val NegativeRed = Color(0xFFEF5350)
val BaseBlue = Color(0xFF1565C0)
val IncompleteGrey = Color(0xFF90A4AE)
val CtaGradient = Brush.horizontalGradient(listOf(PrimaryBlue, AccentOrange))

private val DarkColors = darkColorScheme(
    primary = PrimaryBlue,
    secondary = AccentOrange,
    background = BgDark,
    surface = Color(0xFF182231),
    onBackground = Color.White,
    onSurface = Color.White,
)

private val LightColors = lightColorScheme(
    primary = PrimaryBlue,
    secondary = AccentOrange,
    background = BgLight,
    surface = Color.White,
    onBackground = Color(0xFF162033),
    onSurface = Color(0xFF162033),
)

@Composable
fun TrainTrackTheme(content: @Composable () -> Unit) {
    val dark = isSystemInDarkTheme()
    MaterialTheme(
        colorScheme = if (dark) DarkColors else LightColors,
        typography = Typography(),
        shapes = Shapes(
            extraSmall = androidx.compose.foundation.shape.RoundedCornerShape(12),
            small = androidx.compose.foundation.shape.RoundedCornerShape(18),
            medium = androidx.compose.foundation.shape.RoundedCornerShape(24),
            large = androidx.compose.foundation.shape.RoundedCornerShape(28),
        ),
        content = content,
    )
}
