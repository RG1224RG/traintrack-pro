package com.traintrack.pro.data

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(tableName = "exercises")
data class Exercise(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val userId: Long = 1,
    val name: String,
    val baseReps: Int,
    val baseSets: Int,
    val createdAt: Long = System.currentTimeMillis(),
    val sortOrder: Int = 0,
)

@Entity(
    tableName = "daily_logs",
    foreignKeys = [ForeignKey(
        entity = Exercise::class,
        parentColumns = ["id"],
        childColumns = ["exerciseId"],
        onDelete = ForeignKey.CASCADE,
    )],
    indices = [Index(value = ["date", "exerciseId"], unique = true)],
)
data class DailyLog(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val date: String,
    val exerciseId: Long,
    val baseReps: Int,
    val delta: Int = 0,
    val actualReps: Int = baseReps + delta,
    val isCompleted: Boolean = false,
)

@Entity(tableName = "daily_totals")
data class DailyTotal(
    @PrimaryKey val date: String,
    val totalDelta: Int,
    val completionRate: Float,
)

data class DailyLogWithExercise(
    val id: Long,
    val date: String,
    val exerciseId: Long,
    val baseReps: Int,
    val delta: Int,
    val actualReps: Int,
    val isCompleted: Boolean,
    val exerciseName: String,
)
