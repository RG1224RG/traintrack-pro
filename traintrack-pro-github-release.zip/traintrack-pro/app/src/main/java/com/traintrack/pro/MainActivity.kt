package com.traintrack.pro

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.layout.Box
import androidx.compose.ui.Modifier
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BarChart
import androidx.compose.material.icons.filled.FitnessCenter
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.traintrack.pro.data.DatabaseProvider
import com.traintrack.pro.data.TrainTrackRepository
import com.traintrack.pro.ui.screens.StatisticsScreen
import com.traintrack.pro.ui.screens.StatsViewModel
import com.traintrack.pro.ui.screens.TrainingsplanScreen
import com.traintrack.pro.ui.screens.TrainingsplanViewModel
import com.traintrack.pro.ui.theme.TrainTrackTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        val db = DatabaseProvider.get(this)
        val repository = TrainTrackRepository(db.exerciseDao(), db.dailyLogDao(), db.dailyTotalDao())
        setContent { TrainTrackApp(repository) }
    }
}

@Composable
fun TrainTrackApp(repository: TrainTrackRepository) {
    TrainTrackTheme {
        val planVm: TrainingsplanViewModel = viewModel(factory = TrainingsplanViewModel.factory(repository))
        val statsVm: StatsViewModel = viewModel(factory = StatsViewModel.factory(repository))
        var tab by rememberSaveable { mutableIntStateOf(0) }
        Scaffold(
            containerColor = androidx.compose.material3.MaterialTheme.colorScheme.background,
            bottomBar = {
                NavigationBar {
                    NavigationBarItem(
                        selected = tab == 0,
                        onClick = { tab = 0 },
                        icon = { NavAnimatedIcon(Icons.Filled.FitnessCenter, tab == 0) },
                        label = { Text("Trainingsplan") },
                    )
                    NavigationBarItem(
                        selected = tab == 1,
                        onClick = { tab = 1 },
                        icon = { NavAnimatedIcon(Icons.Filled.BarChart, tab == 1) },
                        label = { Text("Statistiken") },
                    )
                }
            },
        ) { paddingValues ->
            Box(Modifier.padding(paddingValues)) {
                AnimatedVisibility(visible = tab == 0) { TrainingsplanScreen(planVm) }
                AnimatedVisibility(visible = tab == 1) { StatisticsScreen(statsVm) }
            }
        }
    }
}

@Composable
private fun NavAnimatedIcon(icon: androidx.compose.ui.graphics.vector.ImageVector, selected: Boolean) {
    val scale by animateFloatAsState(
        targetValue = if (selected) 1.12f else 1f,
        animationSpec = spring(stiffness = Spring.StiffnessMediumLow),
        label = "tabScale",
    )
    Icon(icon, null, modifier = androidx.compose.ui.Modifier.size((24 * scale).dp))
}
