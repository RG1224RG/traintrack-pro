package com.traintrack.pro.ui.screens

import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.ArrowBackIosNew
import androidx.compose.material.icons.filled.ArrowForwardIos
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.patrykandpatrick.vico.compose.cartesian.CartesianChartHost
import com.patrykandpatrick.vico.compose.cartesian.axis.HorizontalAxis
import com.patrykandpatrick.vico.compose.cartesian.axis.VerticalAxis
import com.patrykandpatrick.vico.compose.cartesian.data.CartesianChartModelProducer
import com.patrykandpatrick.vico.compose.cartesian.data.columnSeries
import com.patrykandpatrick.vico.compose.cartesian.layer.ColumnCartesianLayer
import com.patrykandpatrick.vico.compose.cartesian.layer.rememberColumnCartesianLayer
import com.patrykandpatrick.vico.compose.cartesian.rememberCartesianChart
import com.patrykandpatrick.vico.compose.cartesian.rememberVicoScrollState
import com.patrykandpatrick.vico.compose.common.Fill
import com.patrykandpatrick.vico.compose.common.component.rememberLineComponent
import com.patrykandpatrick.vico.compose.common.CorneredShape
import com.traintrack.pro.data.*
import com.traintrack.pro.ui.theme.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.time.LocalDate
import java.time.temporal.WeekFields
import java.util.Locale

class StatsViewModel(private val repository: TrainTrackRepository) : ViewModel() {
    private val _filter = MutableStateFlow(StatsFilter.WEEK)
    val filter: StateFlow<StatsFilter> = _filter.asStateFlow()
    private val _anchor = MutableStateFlow(LocalDate.now())
    val anchor: StateFlow<LocalDate> = _anchor.asStateFlow()
    private val _bars = MutableStateFlow<List<StatsBar>>(emptyList())
    val bars: StateFlow<List<StatsBar>> = _bars.asStateFlow()
    private val _selectedDate = MutableStateFlow<LocalDate?>(null)
    val selectedDate = _selectedDate.asStateFlow()
    private val _detail = MutableStateFlow<DayDetail?>(null)
    val detail = _detail.asStateFlow()
    private var parentYearDrill = false

    init { refresh() }

    fun setFilter(value: StatsFilter) { _filter.value = value; parentYearDrill = false; refresh() }
    fun move(delta: Int) {
        val current = _anchor.value
        _anchor.value = when (_filter.value) {
            StatsFilter.TODAY, StatsFilter.WEEK -> current.plusWeeks(delta.toLong())
            StatsFilter.MONTH -> current.plusMonths(delta.toLong())
            StatsFilter.SIX_MONTHS -> current.plusMonths(delta.toLong() * 6)
            StatsFilter.YEAR -> current.plusYears(delta.toLong())
        }
        refresh()
    }
    fun openYearWeek(date: LocalDate) {
        parentYearDrill = true
        _filter.value = StatsFilter.WEEK
        _anchor.value = date
        refresh()
    }
    fun selectDate(date: LocalDate) {
        _selectedDate.value = date
        viewModelScope.launch {
            val logs = repository.logsForDate(date)
            val exercises = repository.allExercises()
            val total = logs.sumOf { it.delta }
            val completed = logs.count { it.isCompleted }
            val totalExercises = exercises.size
            val rate = if (totalExercises == 0) 0f else completed * 100f / totalExercises
            val logByExercise = logs.associateBy { it.exerciseId }
            val missing = exercises.filter { ex -> logByExercise[ex.id]?.isCompleted != true }.map { it.name }
            val breakdown = exercises.map { ex -> ex.name to (logByExercise[ex.id]?.delta ?: 0) }
            _detail.value = DayDetail(date, rate, completed, totalExercises, missing, breakdown, total)
        }
    }
    fun closeDetail() { _selectedDate.value = null; _detail.value = null }

    private fun refresh() = viewModelScope.launch {
        _bars.value = when (_filter.value) {
            StatsFilter.TODAY -> repository.detailedDay(_anchor.value)
            StatsFilter.WEEK -> repository.aggregatedWeek(_anchor.value)
            StatsFilter.MONTH -> repository.aggregatedMonth(_anchor.value)
            StatsFilter.SIX_MONTHS -> repository.aggregatedSixMonths(_anchor.value)
            StatsFilter.YEAR -> repository.aggregatedYear(_anchor.value)
        }
    }

    companion object {
        fun factory(repo: TrainTrackRepository) = object : ViewModelProvider.Factory {
            @Suppress("UNCHECKED_CAST") override fun <T : ViewModel> create(modelClass: Class<T>): T = StatsViewModel(repo) as T
        }
    }
}

@Composable
fun StatisticsScreen(vm: StatsViewModel) {
    val filter by vm.filter.collectAsState()
    val anchor by vm.anchor.collectAsState()
    val bars by vm.bars.collectAsState()
    val selected by vm.selectedDate.collectAsState()

    Column(Modifier.fillMaxSize().padding(horizontal = 16.dp, vertical = 12.dp)) {
        Text("Statistiken", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(10.dp))
        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            items(StatsFilter.entries.size) { index ->
                val item = StatsFilter.entries[index]
                FilterChip(selected = item == filter, onClick = { vm.setFilter(item) }, label = { Text(item.label) })
            }
        }
        Spacer(Modifier.height(10.dp))
        Breadcrumbs(filter, anchor, selected)
        PeriodPagerControls(filter, anchor, onPrev = { vm.move(-1) }, onNext = { vm.move(1) })
        Spacer(Modifier.height(8.dp))
        Surface(
            shape = RoundedCornerShape(24.dp),
            tonalElevation = 2.dp,
            modifier = Modifier
                .fillMaxWidth()
                .pointerInput(filter) {
                    detectHorizontalDragGestures(
                        onDragEnd = { },
                        onHorizontalDrag = { change, dragAmount ->
                            if (kotlin.math.abs(dragAmount) > 24f) {
                                if (dragAmount < 0) vm.move(1) else vm.move(-1)
                                change.consume()
                            }
                        },
                    )
                },
        ) {
            Column(Modifier.padding(12.dp)) {
                Text(periodTitle(filter, anchor), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.height(10.dp))
                VicoBars(
                    bars = bars,
                    modifier = Modifier.fillMaxWidth().height(310.dp),
                    onTap = { bar ->
                        when (filter) {
                            StatsFilter.YEAR -> vm.openYearWeek(bar.date)
                            StatsFilter.WEEK, StatsFilter.MONTH -> vm.selectDate(bar.date)
                            StatsFilter.SIX_MONTHS -> vm.openYearWeek(bar.date)
                            StatsFilter.TODAY -> vm.selectDate(bar.date)
                        }
                    },
                )
            }
        }
        Spacer(Modifier.height(12.dp))
        Legend()
    }
    val detail by vm.detail.collectAsState()
    detail?.let { info -> DetailBottomSheet(detail = info, onDismiss = vm::closeDetail) }
}

@Composable
private fun Breadcrumbs(filter: StatsFilter, anchor: LocalDate, selectedDate: LocalDate?) {
    val week = anchor.get(WeekFields.ISO.weekOfWeekBasedYear())
    val text = when (filter) {
        StatsFilter.YEAR -> "Jahre"
        StatsFilter.WEEK -> "Jahre > KW $week" + (selectedDate?.let { " > ${it.dayOfMonth.toString().padStart(2, '0')}.${it.monthValue.toString().padStart(2, '0')}.${it.year}" } ?: "")
        else -> "${anchor.year} > ${filter.label}"
    }
    Surface(color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.7f), shape = RoundedCornerShape(14.dp)) {
        Text(text, modifier = Modifier.padding(horizontal = 12.dp, vertical = 7.dp), style = MaterialTheme.typography.labelLarge)
    }
}

@Composable
private fun PeriodPagerControls(filter: StatsFilter, anchor: LocalDate, onPrev: () -> Unit, onNext: () -> Unit) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
        IconButton(onClick = onPrev) { Icon(Icons.Default.ArrowBackIosNew, "Zurück") }
        Text(periodTitle(filter, anchor), fontWeight = FontWeight.Medium)
        IconButton(onClick = onNext) { Icon(Icons.Default.ArrowForwardIos, "Weiter") }
    }
}

private fun periodTitle(filter: StatsFilter, anchor: LocalDate): String = when (filter) {
    StatsFilter.TODAY -> "Heute"
    StatsFilter.WEEK -> "KW ${anchor.get(WeekFields.ISO.weekOfWeekBasedYear())} · ${anchor.with(java.time.DayOfWeek.MONDAY).dayOfMonth}.${anchor.with(java.time.DayOfWeek.MONDAY).monthValue}.–${anchor.with(java.time.DayOfWeek.SUNDAY).dayOfMonth}.${anchor.with(java.time.DayOfWeek.SUNDAY).monthValue}"
    StatsFilter.MONTH -> "${anchor.month.name.lowercase(Locale.GERMAN).replaceFirstChar { it.titlecase(Locale.GERMAN) }} ${anchor.year}"
    StatsFilter.SIX_MONTHS -> "6 Monate bis ${anchor.monthValue}/${anchor.year}"
    StatsFilter.YEAR -> "${anchor.year} · 52 Wochen"
}

@Composable
private fun VicoBars(bars: List<StatsBar>, modifier: Modifier, onTap: (StatsBar) -> Unit) {
    val modelProducer = remember { CartesianChartModelProducer() }
    LaunchedEffect(bars) {
        modelProducer.runTransaction {
            bars.forEachIndexed { index, bar ->
                columnSeries {
                    series(bars.indices.map { entryIndex -> if (entryIndex == index) bar.value.toDouble() else 0.0 })
                }
            }
        }
    }
    val components = mutableListOf<com.patrykandpatrick.vico.compose.common.component.LineComponent>()
    for (bar in bars) {
        components += rememberLineComponent(
            fill = Fill(barColor(bar)),
            thickness = 22.dp,
            shape = CorneredShape.rounded(topLeftPercent = 100, topRightPercent = 100),
        )
    }
    Box(modifier) {
        CartesianChartHost(
            chart = rememberCartesianChart(
                rememberColumnCartesianLayer(
                    columnProvider = ColumnCartesianLayer.ColumnProvider.series(*components.toTypedArray()),
                    columnCollectionSpacing = 14.dp,
                    mergeMode = { ColumnCartesianLayer.MergeMode.Stacked },
                ),
                startAxis = VerticalAxis.rememberStart(),
                bottomAxis = HorizontalAxis.rememberBottom(),
            ),
            modelProducer = modelProducer,
            scrollState = rememberVicoScrollState(scrollEnabled = true),
            modifier = Modifier.fillMaxSize(),
        )
        Row(Modifier.fillMaxSize()) {
            bars.forEach { bar ->
                Box(Modifier.weight(1f).fillMaxHeight().pointerInput(bar.date, bars.size) {
                    detectTapGestures(onTap = { onTap(bar) })
                })
            }
        }
    }
}

private fun barColor(bar: StatsBar): Color = when {
    bar.completionRate < 100f -> IncompleteGrey
    bar.value > 0 -> PositiveGreen
    bar.value < 0 -> NegativeRed
    else -> BaseBlue
}

@Composable
private fun Legend() {
    Row(horizontalArrangement = Arrangement.spacedBy(14.dp), modifier = Modifier.fillMaxWidth()) {
        LegendDot(PositiveGreen, "+ Delta")
        LegendDot(NegativeRed, "- Delta")
        LegendDot(BaseBlue, "Basis")
        LegendDot(IncompleteGrey, "Unvollständig")
    }
}

@Composable
private fun LegendDot(color: Color, label: String) {
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(5.dp)) {
        Box(Modifier.size(9.dp).clip(RoundedCornerShape(50)).background(color))
        Text(label, style = MaterialTheme.typography.labelSmall)
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun DetailBottomSheet(detail: DayDetail, onDismiss: () -> Unit) {
    ModalBottomSheet(onDismissRequest = onDismiss) {
        Column(Modifier.fillMaxWidth().padding(20.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("${detail.date.dayOfMonth}.${detail.date.monthValue}.${detail.date.year}", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
            Text("${detail.completionRate.toInt()}% · ${detail.completed}/${detail.totalExercises} Übungen")
            if (detail.missing.isNotEmpty()) {
                Text("Fehlend: ${detail.missing.joinToString()}", color = NegativeRed, fontWeight = FontWeight.SemiBold)
            } else {
                Text("Alle Übungen abgeschlossen.", color = PositiveGreen, fontWeight = FontWeight.SemiBold)
            }
            HorizontalDivider()
            detail.breakdown.forEach { (name, delta) ->
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text(name)
                    Text(if (delta >= 0) "+$delta" else delta.toString(), fontWeight = FontWeight.Bold)
                }
            }
            Text("Total ${if (detail.totalDelta >= 0) "+${detail.totalDelta}" else detail.totalDelta}", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(16.dp))
        }
    }
}

@Preview(showBackground = true, widthDp = 412)
@Composable
private fun StatisticsPreview() {
    TrainTrackTheme {
        Surface {
            Text("Jahre · 52 Wochen", modifier = Modifier.padding(24.dp), fontWeight = FontWeight.Bold)
        }
    }
}
