package com.traintrack.pro.ui.screens

import android.view.HapticFeedbackConstants
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.Spring
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGesturesAfterLongPress
import androidx.compose.foundation.layout.*
import kotlinx.coroutines.delay
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.tween
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.animateItemPlacement
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material3.*
import androidx.compose.material3.DismissDirection
import androidx.compose.material3.SwipeToDismissBox
import androidx.compose.material3.SwipeToDismissBoxValue
import androidx.compose.material3.rememberSwipeToDismissBoxState
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import androidx.compose.material.icons.filled.Check
import com.airbnb.lottie.compose.*
import com.traintrack.pro.data.DailyLogWithExercise
import com.traintrack.pro.data.Exercise
import com.traintrack.pro.data.TrainTrackRepository
import com.traintrack.pro.ui.theme.*
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.time.LocalDate

class TrainingsplanViewModel(private val repository: TrainTrackRepository) : ViewModel() {
    private val today = LocalDate.now()
    val exercises = repository.observeExercises().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())
    val logs = repository.observeToday(today).stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    fun add(name: String, reps: Int, sets: Int) = viewModelScope.launch { repository.addExercise(name, reps, sets) }
    fun edit(exercise: Exercise, name: String, sets: Int) = viewModelScope.launch { repository.updateExercise(exercise, name, sets) }
    fun delete(exercise: Exercise) = viewModelScope.launch { repository.deleteExercise(exercise) }
    fun delta(exercise: Exercise, input: String) = viewModelScope.launch { repository.saveDelta(today, exercise, input) }
    fun completed(exercise: Exercise, value: Boolean) = viewModelScope.launch { repository.setCompleted(today, exercise, value) }
    fun reorder(list: List<Exercise>) = viewModelScope.launch { repository.reorder(list) }

    companion object {
        fun factory(repo: TrainTrackRepository) = object : ViewModelProvider.Factory {
            @Suppress("UNCHECKED_CAST")
            override fun <T : ViewModel> create(modelClass: Class<T>): T = TrainingsplanViewModel(repo) as T
        }
    }
}

private data class EditingState(val exercise: Exercise? = null, val create: Boolean = false)

@Composable
fun TrainingsplanScreen(vm: TrainingsplanViewModel) {
    val exercises by vm.exercises.collectAsState()
    val logs by vm.logs.collectAsState()
    var editing by remember { mutableStateOf<EditingState?>(null) }
    var deltaExercise by remember { mutableStateOf<Exercise?>(null) }
    var order by remember(exercises) { mutableStateOf(exercises) }
    var showSkeleton by remember { mutableStateOf(true) }

    LaunchedEffect(exercises) { if (order.map { it.id } != exercises.map { it.id }) order = exercises }
    LaunchedEffect(Unit) { delay(420); showSkeleton = false }

    Column(Modifier.fillMaxSize().padding(horizontal = 16.dp, vertical = 12.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Column {
                Text("Trainingsplan", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
                Text("Heute · ${LocalDate.now().dayOfMonth}.${LocalDate.now().monthValue}.${LocalDate.now().year}", color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            GradientCta(text = "Übung", icon = { Icon(Icons.Default.Add, null) }) { editing = EditingState(create = true) }
        }
        Spacer(Modifier.height(14.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp), contentPadding = PaddingValues(bottom = 24.dp)) {
            if (showSkeleton) {
                items(3) { ShimmerCard() }
            } else {
                itemsIndexed(order, key = { _, item -> item.id }) { index, exercise ->
                    val log = logs.firstOrNull { it.exerciseId == exercise.id }
                    val actual = log?.actualReps ?: exercise.baseReps
                    val completed = log?.isCompleted ?: false
                    ExerciseCard(
                        index = index,
                        exercise = exercise,
                        actual = actual,
                        completed = completed,
                        onChecked = { vm.completed(exercise, it) },
                        onDeltaClick = { deltaExercise = exercise },
                        onEdit = { editing = EditingState(exercise) },
                        onDelete = {
                            order = order.filterNot { it.id == exercise.id }
                            vm.delete(exercise)
                        },
                        onMove = { from, to ->
                            if (to in order.indices && from != to) {
                                val mutable = order.toMutableList()
                                val moved = mutable.removeAt(from)
                                mutable.add(to, moved)
                                order = mutable
                                vm.reorder(mutable)
                            }
                        },
                    )
                }
                if (order.isEmpty()) {
                    item { EmptyPlan(onAdd = { editing = EditingState(create = true) }) }
                }
            }
        }
    }

    editing?.let { state ->
        ExerciseDialog(
            exercise = state.exercise,
            onDismiss = { editing = null },
            onSave = { name, reps, sets ->
                if (state.exercise == null) vm.add(name, reps, sets) else vm.edit(state.exercise, name, sets)
                editing = null
            },
        )
    }

    deltaExercise?.let { exercise ->
        DeltaBottomSheet(
            exercise = exercise,
            today = logs.firstOrNull { it.exerciseId == exercise.id }?.actualReps ?: exercise.baseReps,
            onDismiss = { deltaExercise = null },
            onSave = { input -> vm.delta(exercise, input); deltaExercise = null },
        )
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun ExerciseCard(
    index: Int, exercise: Exercise, actual: Int, completed: Boolean,
    onChecked: (Boolean) -> Unit, onDeltaClick: () -> Unit, onEdit: () -> Unit, onDelete: () -> Unit,
    onMove: (Int, Int) -> Unit,
) {
    val view = LocalView.current
    val dismissState = rememberSwipeToDismissBoxState(
        confirmValueChange = { value ->
            if (value == SwipeToDismissBoxValue.EndToStart) onDelete()
            value != SwipeToDismissBoxValue.StartToEnd
        }
    )
    var dragOffset by remember { mutableFloatStateOf(0f) }

    SwipeToDismissBox(
        state = dismissState,
        enableDismissFromStartToEnd = false,
        backgroundContent = {
            Box(Modifier.fillMaxSize().clip(RoundedCornerShape(24.dp)).background(NegativeRed).padding(horizontal = 22.dp), contentAlignment = Alignment.CenterEnd) {
                Icon(Icons.Filled.Delete, null, tint = androidx.compose.ui.graphics.Color.White)
            }
        },
        content = {
            ElevatedCard(
                modifier = Modifier
                    .animateItemPlacement()
                    .graphicsLayer { translationY = dragOffset }
                    .combinedClickable(
                        role = Role.Button,
                        onClick = {},
                        onLongClick = { view.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS); onEdit() },
                    )
                    .pointerInput(exercise.id, index) {
                        detectDragGesturesAfterLongPress(
                            onDragStart = { view.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS) },
                            onDrag = { change, amount ->
                                change.consume()
                                dragOffset += amount.y
                            },
                            onDragEnd = {
                                val direction = when { dragOffset > 70f -> 1; dragOffset < -70f -> -1; else -> 0 }
                                if (direction != 0) onMove(index, index + direction)
                                dragOffset = 0f
                            },
                            onDragCancel = { dragOffset = 0f },
                        )
                    },
                shape = RoundedCornerShape(24.dp),
            ) {
                Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    AnimatedCheck(completed, onChecked)
                    Spacer(Modifier.width(14.dp))
                    Column(Modifier.weight(1f)) {
                        Text(exercise.name, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                        Text("${exercise.baseSets} Sätze · Basis ${exercise.baseReps} Wdh", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    AssistChip(
                        onClick = { view.performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK); onDeltaClick() },
                        label = { Text("$actual Wdh") },
                        shape = RoundedCornerShape(18.dp),
                        colors = AssistChipDefaults.assistChipColors(
                            containerColor = AccentOrange.copy(alpha = 0.14f),
                            labelColor = AccentOrange,
                        ),
                    )
                    IconButton(onClick = onEdit) { Icon(Icons.Default.MoreVert, null) }
                }
            }
        },
    )
}

@Composable
private fun AnimatedCheck(checked: Boolean, onClick: (Boolean) -> Unit) {
    val composition by rememberLottieComposition(LottieCompositionSpec.RawRes(com.traintrack.pro.R.raw.checkmark))
    Box(Modifier.size(42.dp).clip(RoundedCornerShape(14.dp)).background(if (checked) PrimaryBlue.copy(alpha = 0.12f) else MaterialTheme.colorScheme.surfaceVariant)) {
        IconButton(onClick = { onClick(!checked) }, modifier = Modifier.fillMaxSize()) {
            if (checked) {
                LottieAnimation(composition, progress = { 1f }, modifier = Modifier.size(34.dp))
            } else {
                Icon(Icons.Default.Check, null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}

@Composable
private fun ExerciseDialog(exercise: Exercise?, onDismiss: () -> Unit, onSave: (String, Int, Int) -> Unit) {
    var name by remember(exercise) { mutableStateOf(exercise?.name ?: "") }
    var reps by remember(exercise) { mutableStateOf(exercise?.baseReps?.toString() ?: "15") }
    var sets by remember(exercise) { mutableStateOf(exercise?.baseSets?.toString() ?: "3") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (exercise == null) "Neue Übung" else "Übung bearbeiten") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(name, { name = it }, label = { Text("Name") }, singleLine = true)
                OutlinedTextField(reps, { if (exercise == null) reps = it }, readOnly = exercise != null, label = { Text("Basis-Wdh") }, singleLine = true)
                OutlinedTextField(sets, { sets = it }, label = { Text("Sätze") }, singleLine = true)
                if (exercise != null) Text("Basis-Wdh bleiben unverändert und werden nie durch Tageswerte überschrieben.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        },
        confirmButton = {
            Button(onClick = { onSave(name.trim(), reps.toIntOrNull() ?: 0, sets.toIntOrNull() ?: 0) }, enabled = name.isNotBlank()) { Text("Speichern") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Abbrechen") } },
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun DeltaBottomSheet(exercise: Exercise, today: Int, onDismiss: () -> Unit, onSave: (String) -> Unit) {
    var input by remember(exercise.id) { mutableStateOf("") }
    ModalBottomSheet(onDismissRequest = onDismiss) {
        Column(Modifier.fillMaxWidth().padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text(exercise.name, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
            Text("Basis: ${exercise.baseReps} · Heute: $today Wdh", color = MaterialTheme.colorScheme.onSurfaceVariant)
            OutlinedTextField(
                value = input,
                onValueChange = { input = it.filter { c -> c.isDigit() || c == '+' || c == '-' } },
                modifier = Modifier.fillMaxWidth(),
                label = { Text("+7, -7 oder absolut z.B. 22") },
                supportingText = { Text("22 bei Basis 15 wird als +7 gespeichert.") },
                singleLine = true,
            )
            GradientCta(
                text = "Für heute speichern",
                modifier = Modifier.fillMaxWidth().height(52.dp),
                onClick = { onSave(input) },
            )
            Spacer(Modifier.height(18.dp))
        }
    }
}


@Composable
private fun GradientCta(text: String, modifier: Modifier = Modifier, icon: @Composable (() -> Unit)? = null, onClick: () -> Unit) {
    val view = LocalView.current
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(18.dp))
            .background(CtaGradient)
            .clickable { view.performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK); onClick() }
            .padding(horizontal = 16.dp, vertical = 10.dp),
        contentAlignment = Alignment.Center,
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            icon?.invoke()
            Text(text, color = androidx.compose.ui.graphics.Color.White, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
private fun ShimmerCard() {
    val transition = rememberInfiniteTransition(label = "shimmer")
    val shift by transition.animateFloat(
        initialValue = -1f,
        targetValue = 1.5f,
        animationSpec = infiniteRepeatable(tween(900, easing = LinearEasing), RepeatMode.Restart),
        label = "shimmerShift",
    )
    val brush = Brush.linearGradient(
        colors = listOf(
            MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f),
            MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.9f),
            MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f),
        ),
        start = Offset(shift * 400f, 0f),
        end = Offset(shift * 400f + 280f, 0f),
    )
    Box(Modifier.fillMaxWidth().height(88.dp).clip(RoundedCornerShape(24.dp)).background(brush))
}

@Composable
private fun EmptyPlan(onAdd: () -> Unit) {
    Surface(shape = RoundedCornerShape(24.dp), tonalElevation = 2.dp) {
        Column(Modifier.fillMaxWidth().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("Noch keine Übungen", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            Text("Lege deinen ersten Trainingsbaustein an.", color = MaterialTheme.colorScheme.onSurfaceVariant)
            Button(onClick = onAdd) { Text("Übung hinzufügen") }
        }
    }
}

@Preview(showBackground = true, widthDp = 412)
@Composable
private fun TrainingsplanPreview() {
    com.traintrack.pro.ui.theme.TrainTrackTheme { EmptyPlan {} }
}
