package com.traintrack.pro.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface ExerciseDao {
    @Query("SELECT * FROM exercises WHERE userId = 1 ORDER BY sortOrder ASC, createdAt ASC")
    fun observeExercises(): Flow<List<Exercise>>

    @Insert
    suspend fun insert(exercise: Exercise): Long

    @Update
    suspend fun update(exercise: Exercise)

    @Delete
    suspend fun delete(exercise: Exercise)

    @Query("UPDATE exercises SET sortOrder = :sortOrder WHERE id = :id")
    suspend fun updateSortOrder(id: Long, sortOrder: Int)
}

@Dao
interface DailyLogDao {
    @Query("""
        SELECT d.id, d.date, d.exerciseId, d.baseReps, d.delta, d.actualReps, d.isCompleted, e.name AS exerciseName
        FROM daily_logs d JOIN exercises e ON e.id = d.exerciseId
        WHERE d.date = :date AND e.userId = 1
        ORDER BY e.sortOrder ASC, e.createdAt ASC
    """)
    fun observeLogs(date: String): Flow<List<DailyLogWithExercise>>

    @Query("SELECT * FROM daily_logs WHERE date = :date")
    suspend fun getForDate(date: String): List<DailyLog>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(log: DailyLog)

    @Query("DELETE FROM daily_logs WHERE exerciseId = :exerciseId")
    suspend fun deleteForExercise(exerciseId: Long)

    @Query("UPDATE daily_logs SET isCompleted = :completed WHERE date = :date AND exerciseId = :exerciseId")
    suspend fun setCompleted(date: String, exerciseId: Long, completed: Boolean)

    @Query("SELECT COALESCE(SUM(delta), 0) FROM daily_logs WHERE date = :date")
    suspend fun sumDelta(date: String): Int

    @Query("SELECT COUNT(*) FROM exercises WHERE userId = 1")
    suspend fun countExercises(): Int

    @Query("SELECT COUNT(*) FROM daily_logs WHERE date = :date AND isCompleted = 1")
    suspend fun countCompleted(date: String): Int

    @Query("SELECT * FROM daily_logs WHERE date BETWEEN :from AND :to ORDER BY date ASC")
    suspend fun getBetween(from: String, to: String): List<DailyLog>

    @Query("SELECT * FROM daily_logs WHERE date = :date AND exerciseId = :exerciseId LIMIT 1")
    suspend fun find(date: String, exerciseId: Long): DailyLog?
}

@Dao
interface DailyTotalDao {
    @Query("SELECT * FROM daily_totals WHERE date = :date LIMIT 1")
    suspend fun find(date: String): DailyTotal?

    @Upsert
    suspend fun upsert(total: DailyTotal)
}

